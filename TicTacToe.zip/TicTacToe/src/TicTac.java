import java.util.Scanner;

public class TicTac {

    public static char[][] board = new char[3][3];
    public static char name = 'X';

    public static void initialDisplay() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = ' ';
            }
        }
    }

    public static void displayBoard() {
        System.out.println("-------------");
        for (int i = 0; i < 3; i++) {
            System.out.print("| ");
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j] + " | ");
            }
            System.out.println("\n-------------");
        }
    }

    public static boolean win() {
        // Check rows and columns
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == name && board[i][1] == name && board[i][2] == name) {
                return true;
            } else if (board[0][i] == name && board[1][i] == name && board[2][i] == name) {
                return true;
            }
        }

        // Check diagonals
        if (board[0][0] == name && board[1][1] == name && board[2][2] == name) {
            return true;
        } else if (board[0][2] == name && board[1][1] == name && board[2][0] == name) {
            return true;
        }

        return false;
    }

    public static boolean isFull() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == ' ') {
                    return false;
                }
            }
        }
        return true;
    }

    public static void player() {
        // Alternate player turn
        name = (name == 'X') ? 'O' : 'X';
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int r, c;
        initialDisplay();

        while (true) {
            displayBoard(); // Display current board
            System.out.println("Player " + name + "'s turn. Enter row (0-2) and column (0-2): ");
            r = sc.nextInt();
            c = sc.nextInt();

            if (r < 0 || r > 2 || c < 0 || c > 2 || board[r][c] != ' ') {
                System.out.println("Invalid choice! Try again.");
            } else {
                board[r][c] = name;

                if (win()) {
                    displayBoard();
                    System.out.println("Player " + name + " wins!");
                    break; // End the game after a win
                }

                if (isFull()) {
                    displayBoard();
                    System.out.println("The match is a draw!");
                    break; // End the game after a draw
                }

                player(); // Switch to the next player
            }
        }
        sc.close(); // Close the scanner to prevent resource leak
    }
}
